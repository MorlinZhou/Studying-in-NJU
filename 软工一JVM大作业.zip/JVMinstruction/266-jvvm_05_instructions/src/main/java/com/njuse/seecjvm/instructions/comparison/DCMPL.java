package com.njuse.seecjvm.instructions.comparison;

import com.njuse.seecjvm.instructions.base.NoOperandsInstruction;
import com.njuse.seecjvm.runtime.StackFrame;

public class DCMPL extends NoOperandsInstruction {

    /**
     * TODO：实现这条指令
     */
    @Override
    public void execute(StackFrame frame) {
        double value2=frame.getOperandStack().popDouble();
        double value1=frame.getOperandStack().popDouble();
        if(Double.isNaN(value1)||Double.isNaN(value2)||value1<value2){
            frame.getOperandStack().pushInt(-1);
        }
        else if (value1==value2){
            frame.getOperandStack().pushInt(0);
        }
        else if (value1>value2) {
            frame.getOperandStack().pushInt(1);
        }
    }
}
