package edu.nju;

import java.io.IOException;

/**
 * format : dir/subdir;dir/subdir/*;dir/target.jar*
 */
public class CompositeEntry extends Entry{
    public CompositeEntry(String classpath) {
        super(classpath);
    }

    @Override
    public byte[] readClassFile(String className) throws IOException {
        String[] path=classpath.split(PATH_SEPARATOR);
        byte[] dir=null;
            for (String a : path) {
                Entry t = ClassFileReader.chooseEntryType(a);
                dir = t.readClassFile(className);
                if (dir != null) break;
            }


        return dir;
    }
}
