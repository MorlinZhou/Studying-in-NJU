package edu.nju;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * format : dir/subdir/.../
 */
public class DirEntry extends Entry{
    public DirEntry(String classpath) {
        super(classpath);
    }

    @Override
    public byte[] readClassFile(String className) throws IOException {
        File dir=new File(classpath);
        String path=dir.getAbsolutePath();
        String realpath=IOUtil.transform(String.join(FILE_SEPARATOR,path,className));//转化为标准格式的路径和文件名地址
        File file=new File(realpath);
        if (file.exists()){
            FileInputStream thepath=new FileInputStream(realpath);
            return IOUtil.readFileByBytes(thepath);
        }
        return null;
    }
}
