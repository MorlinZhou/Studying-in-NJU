package edu.nju;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.jar.JarFile;
import java.util.stream.Collectors;

/**
 * format : dir/.../*
 */
public class WildEntry extends Entry{
    public WildEntry(String classpath) {
        super(classpath);
    }

    @Override
    public byte[] readClassFile(String className) throws IOException {
        String realdir=classpath.substring(0,classpath.length()-2);
        File dir=new File(realdir);
        File[] dirlist=dir.listFiles((f)->f.getName().endsWith(".jar")||f.getName().endsWith(".JAR"));
        String classpath= Arrays.stream(dirlist).map(File::getAbsolutePath).collect(Collectors.joining(this.PATH_SEPARATOR));
        CompositeEntry entry=new CompositeEntry(classpath);
        return entry.readClassFile(className);


    }
}
