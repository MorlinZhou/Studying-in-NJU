package com.njuse.seecjvm.memory.jclass;

import com.njuse.seecjvm.classloader.classfileparser.MethodInfo;
import com.njuse.seecjvm.classloader.classfileparser.attribute.CodeAttribute;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class Method extends ClassMember {
    private int maxStack;
    private int maxLocal;
    private int argc;
    private byte[] code;

    public Method(MethodInfo info, JClass clazz) {
        this.clazz = clazz;
        accessFlags = info.getAccessFlags();
        name = info.getName();
        descriptor = info.getDescriptor();

        CodeAttribute codeAttribute = info.getCodeAttribute();
        if (codeAttribute != null) {
            maxLocal = codeAttribute.getMaxLocal();
            maxStack = codeAttribute.getMaxStack();
            code = codeAttribute.getCode();
        }
        argc = calculateArgcFromDescriptor(descriptor);
    }
    //todo calculateArgcFromDescriptor
    private int calculateArgcFromDescriptor(String descriptor) {
        char[] chars=descriptor.toCharArray();
        int max=descriptor.lastIndexOf(')');
        int index=descriptor.lastIndexOf('(');
        assert max!=-1;
        assert index!=-1;
        index++;
        int cnt=0;
        while(index<=max) {
            switch (chars[index++]) {
                case 'B':
                    cnt+=1;
                    break;
                case 'C':
                    cnt+=1;
                    break;
                case 'D':
                    cnt+=2;
                    break;
                case 'F':
                    cnt+=1;
                    break;
                case 'I':
                    cnt+=1;
                    break;
                case 'J':
                    cnt+=2;
                    break;
                case 'S':
                    cnt+=1;
                    break;
                case 'Z':
                    cnt+=1;
                    break;
                case 'L':
                    cnt++;
                    while (index < max) {
                        index++;
                        if (chars[index]==';')
                            break;
                    }
                    break;
                case '[':
                    break;

            }
        }




        /**
         * Add some codes here.
         * Here are some examples in README!!!
         *
         * You should refer to JVM specification for more details
         *
         * Beware of long and double type
         */

        return cnt;
    }
}
