package com.njuse.seecjvm.instructions.references;

import com.njuse.seecjvm.instructions.base.Index16Instruction;
import com.njuse.seecjvm.memory.jclass.Field;
import com.njuse.seecjvm.memory.jclass.JClass;
import com.njuse.seecjvm.memory.jclass.runtimeConstantPool.RuntimeConstantPool;
import com.njuse.seecjvm.memory.jclass.runtimeConstantPool.constant.ref.FieldRef;
import com.njuse.seecjvm.runtime.OperandStack;
import com.njuse.seecjvm.runtime.StackFrame;
import com.njuse.seecjvm.runtime.Vars;
import com.njuse.seecjvm.runtime.struct.NonArrayObject;

public class GETFIELD extends Index16Instruction {

    /**
     * TODO 实现这条指令
     * 其中 对应的index已经读取好了
     */
    @Override
    public void execute(StackFrame frame) {
        RuntimeConstantPool runtimeConstantPool = frame.getMethod().getClazz().getRuntimeConstantPool();
        FieldRef fieldRef = (FieldRef) runtimeConstantPool.getConstant(index);
        Field field = null;
        try{
            field = fieldRef.getResolvedFieldRef();
            JClass targetClazz = field.getClazz();
            if(field.isStatic()){
                throw new IncompatibleClassChangeError();
            }
            OperandStack operandStack = frame.getOperandStack();
            NonArrayObject ref = (NonArrayObject) operandStack.popObjectRef();
            if(ref.isNull()){
                throw new NullPointerException();
            }
            String descriptor = field.getDescriptor();
            int slotID = field.getSlotID();
            Vars fields = ref.getFields();
            switch (descriptor.charAt(0)){
                case 'Z':
                case 'B':
                case 'C':
                case 'S':
                case 'I':
                    operandStack.pushInt(fields.getInt(slotID));
                    break;
                case 'F':
                    operandStack.pushFloat(fields.getFloat(slotID));
                    break;
                case 'J':
                    operandStack.pushLong(fields.getLong(slotID));
                    break;
                case 'D':
                    operandStack.pushDouble(fields.getDouble(slotID));
                    break;
                case 'L':
                case '[':
                    operandStack.pushObjectRef(fields.getObjectRef(slotID));
                    break;
                default:

            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


    }
}
