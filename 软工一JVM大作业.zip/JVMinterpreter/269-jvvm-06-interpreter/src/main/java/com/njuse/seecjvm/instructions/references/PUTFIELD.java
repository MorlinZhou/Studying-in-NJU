package com.njuse.seecjvm.instructions.references;

import com.njuse.seecjvm.instructions.base.Index16Instruction;
import com.njuse.seecjvm.memory.jclass.Field;
import com.njuse.seecjvm.memory.jclass.JClass;
import com.njuse.seecjvm.memory.jclass.Method;
import com.njuse.seecjvm.memory.jclass.runtimeConstantPool.RuntimeConstantPool;
import com.njuse.seecjvm.memory.jclass.runtimeConstantPool.constant.ref.FieldRef;
import com.njuse.seecjvm.runtime.OperandStack;
import com.njuse.seecjvm.runtime.StackFrame;
import com.njuse.seecjvm.runtime.struct.JObject;
import com.njuse.seecjvm.runtime.struct.NonArrayObject;


public class PUTFIELD extends Index16Instruction {
    /**
     * TODO 实现这条指令
     * 其中 对应的index已经读取好了
     */
    @Override
    public void execute(StackFrame frame) {
        Method method = frame.getMethod();
        JClass jclazz = method.getClazz();
        RuntimeConstantPool runtimeConstantPool = frame.getMethod().getClazz().getRuntimeConstantPool();
        FieldRef fieldRef = (FieldRef) runtimeConstantPool.getConstant(index);
        Field field = null;
        try{
            field = fieldRef.getResolvedFieldRef();
            JClass targetClazz = field.getClazz();
            if(field.isStatic()){
                throw new IncompatibleClassChangeError();
            }
            OperandStack operandStack = frame.getOperandStack();
            JObject ref;
            String descriptor = field.getDescriptor();
            int slotID = field.getSlotID();
            switch (descriptor.charAt(0)){
                case 'Z':
                case 'B':
                case 'C':
                case 'S':
                case 'I':
                    int ivalue = operandStack.popInt();
                    ref = operandStack.popObjectRef();
                    ((NonArrayObject)ref).getFields().setInt(slotID,ivalue);
                    break;
                case 'F':
                    float fvalue = operandStack.popFloat();
                    ref = operandStack.popObjectRef();
                    ((NonArrayObject)ref).getFields().setFloat(slotID,fvalue);
                    break;
                case 'J':
                    Long jvalue = operandStack.popLong();
                    ref = operandStack.popObjectRef();
                    ((NonArrayObject)ref).getFields().setLong(slotID,jvalue);
                    break;
                case 'D':
                    double dvalue = operandStack.popDouble();
                    ref = operandStack.popObjectRef();
                    ((NonArrayObject)ref).getFields().setDouble(slotID,dvalue);
                case 'L':
                default:

            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

}
