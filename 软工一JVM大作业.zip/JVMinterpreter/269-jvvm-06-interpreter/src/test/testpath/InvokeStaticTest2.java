
public class InvokeStaticTest2{
    private static int a = 4;
    public static void main(String[] args) {
        //no code here
        TestUtil.equalInt(a,2);
    }
}