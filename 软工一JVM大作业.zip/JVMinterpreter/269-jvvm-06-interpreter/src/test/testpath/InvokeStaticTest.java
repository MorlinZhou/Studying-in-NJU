
public class InvokeStaticTest{
    private static int a = 3;
    public static void main(String[] args) {
        //no code here
        TestUtil.equalInt(a,2);
    }
}