package memory.cacheMappingStrategy;

import memory.Cache;
import memory.Memory;
import memory.cacheReplacementStrategy.ReplacementStrategy;
import transformer.Transformer;

public class AssociativeMapping extends MappingStrategy {  // 全相联映射

    /**
     * @param blockNO 内存数据块的块号
     * @return cache数据块号 22-bits  [前22位有效]
     */
    @Override
    public char[] getTag(int blockNO) {
        return new Transformer().integerRepresentation(String.valueOf(blockNO),22).toCharArray();
    }

    @Override
    public int map(int blockNO) {
        ReplacementStrategy replacementStrategy = this.replacementStrategy;
        int start = 0;
        int end = (Cache.CACHE_SIZE_B/Cache.LINE_SIZE_B)-1;
        return replacementStrategy.isHit(start,end,getTag(blockNO));
    }

    @Override
    public int writeCache(int blockNO) {
        int start = 0;
        int end = (Cache.CACHE_SIZE_B/Cache.LINE_SIZE_B) -1;
        char[] input = memory.read(new Transformer().integerRepresentation(String.valueOf(blockNO),22)+"0000000000", Cache.LINE_SIZE_B);
        return this.replacementStrategy.writeCache(start,end,getTag(blockNO),input);
    }
}
