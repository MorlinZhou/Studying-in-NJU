package memory.cacheMappingStrategy;

import memory.Cache;
import memory.Memory;
import memory.cacheReplacementStrategy.ReplacementStrategy;
import transformer.Transformer;

import java.util.Arrays;
import java.util.Calendar;

/**
 * 直接映射 12位标记 + 10位块号 + 10位块内地址
 */
public class DirectMapping extends MappingStrategy{

    /**
     * @param blockNO 内存数据块的块号
     * @return cache数据块号 22-bits  [前12位有效]
     */
    @Override
    public char[] getTag(int blockNO) {
        return (new Transformer().integerRepresentation(String.valueOf(blockNO),22).substring(0,12)+"0000000000").toCharArray();
    }


    /**
     * 根据内存地址找到对应的行是否命中，直接映射不需要用到替换策略
     * @param blockNO
     * @return -1 表示未命中
     */
    @Override
    public int map(int blockNO) {
        if(blockNO>=0&&blockNO<(Memory.MEM_SIZE_B/Cache.LINE_SIZE_B)){
            int line = blockNO%(Cache.CACHE_SIZE_B/Cache.LINE_SIZE_B);
            if(Arrays.equals(Cache.getCache().cache.get(line).getTag(), getTag(blockNO))){
                if(!clPool[line].validBit){
                    return -1;
                }
                clPool[line].visited++;
                clPool[line].visitedTimeStamp = Calendar.getInstance().getTimeInMillis();
                return line;
            }else {
                return -1;
            }
        }
        return -1;
    }

    /**
     * 在未命中情况下重写cache，直接映射不需要用到替换策略
     * @param blockNO
     * @return
     */
    @Override
    public int writeCache(int blockNO) {
        int line = blockNO%(Cache.CACHE_SIZE_B/Cache.LINE_SIZE_B);
        String eip = new Transformer().integerRepresentation(String.valueOf(blockNO),22) + "0000000000";
        char[] input = memory.read(eip,Cache.LINE_SIZE_B);
        clPool[line].setTag(getTag(blockNO));
        clPool[line].setData(input);
        clPool[line].validBit = true;
        clPool[line].visited=1;
        clPool[line].inTimeStamp = Calendar.getInstance().getTimeInMillis();
        clPool[line].visitedTimeStamp = Calendar.getInstance().getTimeInMillis();
        return line;
    }


}
