package memory.cacheMappingStrategy;

import memory.Cache;
import memory.Memory;
import transformer.Transformer;

/**
 * 4路-组相连映射 n=4,   14位标记 + 8位组号 + 10位块内地址
 * 256个组，每个组4行
 */
public class SetAssociativeMapping extends MappingStrategy{

    /**
     *
     * @param blockNO 内存数据块的块号
     * @return cache数据块号 22-bits  [前14位有效]
     */
    @Override
    public char[] getTag(int blockNO) {
        return (new Transformer().integerRepresentation(String.valueOf(blockNO),22).substring(0,14)+"00000000").toCharArray();
    }

    /**
     *
     * @param blockNO 目标数据内存地址前22位int表示
     * @return -1 表示未命中
     */
    @Override
    public int map(int blockNO) {
        int start = (blockNO%(Cache.CACHE_SIZE_B/(Cache.LINE_SIZE_B*4)))*4;
        int end = start+3;
        return this.replacementStrategy.isHit(start,end,getTag(blockNO));
    }

    @Override
    public int writeCache(int blockNO) {
        int start = (blockNO%(Cache.CACHE_SIZE_B/(Cache.LINE_SIZE_B*4)))*4;
        int end = start+3;
        char[] input = memory.read(new Transformer().integerRepresentation(String.valueOf(blockNO),22)+"0000000000", Cache.LINE_SIZE_B);
        return this.replacementStrategy.writeCache(start,end,getTag(blockNO),input);
    }
}










