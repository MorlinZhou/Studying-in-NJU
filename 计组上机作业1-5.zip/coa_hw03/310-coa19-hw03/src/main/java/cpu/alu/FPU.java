package cpu.alu;

import transformer.Transformer;
import util.IEEE754Float;

/**
 * floating point unit
 * 执行浮点运算的抽象单元
 * 浮点数精度：使用4位保护位进行计算，计算完毕直接舍去保护位
 * TODO: 浮点数运算
 */
public class FPU {

    /**
     * compute the float mul of a * b
     * 分数部分(23 bits)的计算结果直接截取前23位
     */
    String mul(String a, String b) {
        String sign;
        if(a.substring(0,1).equals(b.substring(0,1))){
            sign = "0";
        }else {
            sign = "1";
        }
        int exponenta = new Transformer().valueOf(a.substring(1,9),2);
        int exponentb = new Transformer().valueOf(b.substring(1,9),2);
        if(exponenta==255||exponentb==255){
            return IEEE754Float.NaN;
        }
        if(a.substring(1).equals("0000000000000000000000000000000")){
            if(sign.equals("0"))
                return IEEE754Float.P_ZERO;
            else
                return IEEE754Float.N_ZERO;
        }
        else if (b.substring(1).equals("0000000000000000000000000000000")){
            if(sign.equals("0"))
                return IEEE754Float.P_ZERO;
            else
                return IEEE754Float.N_ZERO;
        }
        else {
            int exponent = exponenta + exponentb -127;
            if(exponent>=255)
                return IEEE754Float.NaN;
            if(exponent<0){
                if(sign.equals("0"))
                    return IEEE754Float.P_ZERO;
                else
                    return IEEE754Float.N_ZERO;
            }
            String significandsa, significandsb;
            if(exponenta!=0)
                significandsa = "1" + a.substring(9,31);
            else
                significandsa = a.substring(9);
            if (exponentb!=0)
                significandsb = "1" + b.substring(9,31);
            else
                significandsb = b.substring(9);
            String significands = new ALU().mul_significands(significandsa, significandsb);
            if(exponent==0){
                return sign + new Transformer().integerRepresentation(String.valueOf(exponent),8) + significands.substring(23,46);
            }
            while (!significands.substring(23,24).equals("1")){
                significands = new ALU().shr("1",significands);
                exponent++;
                if(exponent>=255){
                    return IEEE754Float.NaN;
                }
            }
            exponent += new Transformer().valueOf(significands.substring(0,23),2);
            if(exponent>=255)
                return IEEE754Float.NaN;
            return sign + new Transformer().integerRepresentation(String.valueOf(exponent),8) + significands.substring(24,47);
        }
    }
    /**
     * compute the float add of (a + b)
     **/
    String add(String a,String b){
        String result = "";
        // if one is 0
        if(a.substring(1).equals("0000000000000000000000000000000")){
            return b;
        }else {
            if(b.substring(1).equals("0000000000000000000000000000000")){
                return a;
            }else {
                int expa = new Transformer().valueOf(a.substring(1,9),2);
                int expb = new Transformer().valueOf(b.substring(1,9),2);
                int exp;
                // adjust exponent
                String fractiona = "";
                String fractionb = "";
                String fraction = "";
                String sign = "";
                if(expa==0){
                    fractiona = "0" + a.substring(9) + "0000";
                }else {
                    fractiona = "1" + a.substring(9) + "0000";
                }
                if(expb==0){
                    fractionb = "0" + b.substring(9) + "0000";
                }else {
                    fractionb = "1" + b.substring(9) + "0000";
                }
                while (expa!=expb){
                    if(expa<expb){
                        expa = expa +1;
                        fractiona = new ALU().shr(new Transformer().intToBinary("1"),fractiona);
                        if(new Transformer().valueOf(fractiona.substring(0,24),2)==0)
                            return b;
                    }else {
                        expb = expb + 1;
                        fractionb = new ALU().shr("1",fractionb);
                        if(new Transformer().valueOf(fractionb.substring(0,24),2)==0)
                            return a;
                    }
                }
                // Add signed significands
                boolean isOverflow=false;
                if(a.substring(0,1).equals(b.substring(0,1))){
                    String temp = new ALU().add("0"+fractiona,"0"+ fractionb);
                    if(temp.substring(0,1).equals("1"))
                        isOverflow = true;
                    else
                        isOverflow = false;
                    sign = a.substring(0,1);
                    fraction = temp.substring(1);
                }else {
                    String temp = new ALU().add("0"+fractiona,"0" + new Transformer().oneAdder(new Transformer().negation(fractionb)).substring(1));
                    if(!temp.substring(0,1).equals("1")){
                        temp = new Transformer().oneAdder(new Transformer().negation(temp.substring(1))).substring(1);
                        sign = new Transformer().negation(a.substring(0,1));
                        fraction = temp;
                    }else {
                        sign = a.substring(0,1);
                        fraction = temp.substring(1);
                    }
                }
                exp = expa;
                // significand = 0
                if(new Transformer().valueOf(fraction.substring(0,24),2)==0){
                    return new Transformer().floatToBinary("0.0");
                }
                if(isOverflow){
                    fraction = "1" + new ALU().shr("1",fraction).substring(1);
                    exp = expa + 1;
                    if(exp>=255){
                        result = sign + new Transformer().integerRepresentation(String.valueOf(exp),8) + fraction.substring(1,24);
                        if(expa!=255&&expb!=255){
                            return "01111111100000000000000000000000";
                        }else {
                            return new Transformer().binaryToFloat(result);
                        }
                    }
                }

                while (!fraction.substring(0,1).equals("1")&&exp>0){
                    fraction = new ALU().shl("1", fraction);
                    exp = exp - 1;
                }
                result = sign + new Transformer().integerRepresentation(String.valueOf(exp),8) + fraction.substring(1,24);
                return result;

            }
        }
    }

    /**
     * compute the float add of (a - b)
     **/
    String sub(String a,String b){
        b = new Transformer().negation(b.substring(0,1)) + b.substring(1);
        return add(a,b);
    }


}
