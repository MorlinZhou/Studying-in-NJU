package transformer;

import java.util.ArrayList;

public class Transformer {



    public static void main(String[] args){
        System.out.println("Int and Binary");
        System.out.println(new Transformer().decimalToNBCD("-213"));
        System.out.println(new Transformer().NBCDToDecimal("11010000000000000000001000010011"));

    }

    /**
     * Integer to binaryString
     *
     * @param numStr to be converted
     * @return result
     */
    public String intToBinary(String numStr) {
        String result = "";
        result = getComplementBinaryCode(numStr);
        return result;
    }

    /**
     * BinaryString to Integer
     *
     * @param binStr : Binary string in 2's complement
     * @return :result
     */
    public String binaryToInt(String binStr) {
        long result = 0;
        result = -(Integer.parseInt(String.valueOf(binStr.charAt(0)))) * (long)Math.pow(2,31);
        for(int i=1;i<32;i++){
            result += (Integer.parseInt(String.valueOf(binStr.charAt(i)))) * (int)Math.pow(2,31-i);
        }
        return String.valueOf(result);
    }

    /**
     * Float true value to binaryString
     * @param floatStr : The string of the float true value
     * */
    public String floatToBinary(String floatStr) {
        String result = "";
        float value = Float.parseFloat(floatStr);
        String signSiganl = "0";
        int exponent = 127;
        if(value<0){
            signSiganl = "1";
            value = -value;
        }
        // 如果为0
        if(value==0){
            result = signSiganl+"0000000000000000000000000000000";
        }else {
            while (value>=2){
                exponent +=1;
                if(exponent>=255)
                    break;
                value = value/2;
            }
            while (value<1){
                exponent -= 1;
                if(exponent==0)
                    break;
                value = 2*value;
            }
            if(value>=2){
                if(signSiganl.equals("0"))
                    return "+Inf";
                else
                    return "-Inf";
            }else if(value<1){
                result = signSiganl + "00000000" + getFractionBinaryCode(value,23);
            }else {
                result = signSiganl + getOriginalBinaryCode(exponent,8) + getFractionBinaryCode(value-1,23);
            }
        }
        return result;
    }

    /**
     * Binary code to its float true value
     * */
    public String binaryToFloat(String binStr) {
        String exponentStr = binStr.substring(1,9);
        int exponent = -127;
        for(int i=0;i<8;i++){
            exponent = exponent + (Integer.parseInt(String.valueOf(exponentStr.charAt(i)))) * (int)Math.pow(2,7-i);
        }
        String fractionStr = binStr.substring(9);
        double fraction = 0.0;
        for(int i=0;i<23;i++){
            fraction = fraction + (Integer.parseInt(String.valueOf(fractionStr.charAt(i)))) * Math.pow(2,-i-1);
        }
        if(exponent==-127){
            if(binStr.charAt(0)=='1')
                return String.valueOf(-fraction*Math.pow(2,-126));
            else
                return String.valueOf(fraction*Math.pow(2,-126));
        }else if(exponent == 128){
            if(fraction==0){
                if(binStr.charAt(0)=='0')
                    return "+Inf";
                else
                    return "-Inf";
            }else {
                return String.valueOf(Float.NaN);
            }
        }else{
            if(binStr.charAt(0)=='1')
                return String.valueOf(-(fraction+1)*Math.pow(2,exponent));
            else
                return String.valueOf((fraction+1)*Math.pow(2,exponent));
        }
    }

    /**
     * The decimal number to its NBCD code
     * */
    public String decimalToNBCD(String decimal) {
        String result="";
        int i = 0;
        if(decimal.charAt(i)=='-'){
            result += "1101";
            i++;
        }else {
            result += "1100";
        }

        for(;i<decimal.length();i++){
            result += getOriginalBinaryCode(Integer.parseInt(String.valueOf(decimal.charAt(i))),4);
        }
        while (result.length()<32){
            result = result.substring(0,4)+"0000"+result.substring(4);
        }
        return result;
    }

    /**
     * NBCD code to its decimal number
     * */
    public String NBCDToDecimal(String NBCDStr) {
        int result = 0;
        ArrayList<String> code = getStrList(NBCDStr,4);
        for(int i=1;i<code.size();i++){
            result = getOriginalValue(code.get(i),4) + 10*result;
        }
        if(code.get(0).equals("1101")){
            result = -result;
        }
        return String.valueOf(result);
    }

//    private static String transformComplementToPositive(String binStr){
//        String result = "";
//        int index = binStr.lastIndexOf("1");
//        for(int i=0;i<index;i++){
//            if(binStr.charAt(i)=='0'){
//                result = result + "1";
//            }else {
//                result = result + "0";
//            }
//        }
//        result += binStr.substring(index);
//        return result;
//    }

    private static String getComplementBinaryCode(String code){
        int value = Integer.parseInt(code);
        boolean isNegative = false;
        String result = "";
        if(value<0){
            isNegative = true;
            value = -value;
        }
        for(int i=0;i<32;i++){
            if(value%2==0){
                if(isNegative){
                    result = 1 + result;
                }else {
                    result = 0 + result;
                }
            }else {
                if(isNegative)
                    result = 0 + result;
                else
                    result = 1 + result;
            }
            value = value/2;
        }
        if(isNegative){
            int i;
            for(i=32-1;i>=0;i--){
                if(result.charAt(i)=='1'){
                    if(i != 32-1)
                        result = result.substring(0,i) + 0 + result.substring(i+1,32);
                    else
                        result = result.substring(0,i) + 0;
                }else {
                    break;
                }
            }
            if(i!=32-1)
                result = result.substring(0,i)+1+result.substring(i+1,32);
            else
                result = result.substring(0,i) + 1;
        }
        return result;
    }

    private static String getOriginalBinaryCode(int a, int slength){
        String result = "";
        for(int i=0;i<slength;i++){
            if(a%2==0){
                result = "0" + result;
            }else {
                result = 1 + result;
            }
            a = a/2;
        }
        return result;
    }

    private static int getOriginalValue(String code, int length){
        int result =0;
        for(int i=0;i<length;i++){
            result += Integer.parseInt(String.valueOf(code.charAt(i)))*(int)Math.pow(2,length-1-i);
        }
        return result;
    }

    private static String getFractionBinaryCode(float a,int slength){
        String result = "";
        for(int i=0;i<slength;i++){
            a = 2*a;
            if(a>=1){
                result = result + "1";
                a = a-1;
            }else {
                result = result + "0";
            }
        }
        return result;
    }

    private static ArrayList<String> getStrList(String inputString, int length) {
        int size = inputString.length()/length;
        ArrayList<String> list = new ArrayList<String>();
        for (int index = 0; index < size; index++) {
            String childStr = inputString.substring(index*length,(index+1)*length);
            list.add(childStr);
        }
        return list;
    }

}
