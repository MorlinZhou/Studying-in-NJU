package cpu.alu;

import transformer.Transformer;

/**
 * Arithmetic Logic Unit
 * ALU封装类
 * TODO: 加减乘除
 */
public class ALU {

    // 模拟寄存器中的进位标志位
    private String CF = "0";

    // 模拟寄存器中的溢出标志位
    private String OF = "0";

    //add two integer
    String add(String src, String dest) {
        String result = "";
        CF = "0";
        OF = "0";
        for(int i=dest.length()-1;i>=0;i--){
            String s = xor(xor(src.substring(i,i+1),dest.substring(i,i+1)),CF);
            result = s + result;
            CF = or(or(and(src.substring(i,i+1),dest.substring(i,i+1)),and(src.substring(i,i+1),CF)),and(dest.substring(i,i+1),CF));
        }
        OF = or(and(and(src.substring(0,1),dest.substring(0,1)),new Transformer().negation(result.substring(0,1))),
                and(and(new Transformer().negation(src.substring(0,1)),new Transformer().negation(dest.substring(0,1))),
                        result.substring(0,1)));
        return result;
    }

    //sub two integer
    // dest - src
    String sub(String src, String dest) {
        src = new Transformer().intToBinary(String.valueOf(-Integer.parseInt(new Transformer().binaryToInt(src))));
        return add(src,dest);
	}

    //signed integer mod
    String imod(String operand2, String operand1) {
        String temp = operand1.substring(0,32);
        String quotient;
        String sign = operand1.substring(0,1);
        for(int i=0;i<32;i++){
            operand1 = sign + operand1;
        }
        if(isSameSign(operand2,temp)){
            operand1 = sub(operand2,operand1.substring(0,32)) + operand1.substring(32);
        }else {
            operand1 = add(operand2,operand1.substring(0,32)) + operand1.substring(32);
        }
        if(isSameSign(operand2,operand1)){
            quotient = "1";
        }else {
            quotient="0";
        }
        for(int i=0;i<32;i++){
            if(isSameSign(operand1,operand2)){
                operand1 = shl(new Transformer().intToBinary("1"),operand1);
                operand1 = operand1.substring(0,operand1.length()-1) + quotient;
                operand1 = sub(operand2,operand1.substring(0,32)) + operand1.substring(32);
            }
            else {
                operand1 = shl(new Transformer().intToBinary("1"),operand1);
                operand1 = operand1.substring(0,operand1.length()-1) + quotient;
                operand1 = add(operand1.substring(0,32),operand2) + operand1.substring(32);
            }
            if(isSameSign(operand2,operand1))
                quotient="1";
            else
                quotient="0";
        }
        quotient = operand1.substring(32);
        quotient = shl(new Transformer().intToBinary("1"),quotient);
        if(quotient.substring(0,1).equals("1")){
            quotient = add(quotient,new Transformer().intToBinary("1"));
        }
        if(!isSameSign(operand1,temp)){
            if(isSameSign(temp,operand2)){
                operand1 = add(operand1.substring(0,32),operand2) + operand1.substring(32);
            }else {
                operand1 = sub(operand2,operand1.substring(0,32)) + operand1.substring(32);
            }
        }
		return operand1.substring(0,32);
    }

    boolean isSameSign(String src, String dest){
        if(src.substring(0,1).equals(dest.substring(0,1)))
            return true;
        else
            return false;
    }

    String and(String src, String dest) {
        String result="";
        for(int i=0;i<src.length();i++){
            if(src.substring(i,i+1).equals("1")&&dest.substring(i,i+1).equals("1"))
                result = result + "1";
            else
                result = result + "0";
        }
        return result;
    }

    String or(String src, String dest) {
        String result="";
        for(int i=0;i<src.length();i++){
            if(src.substring(i,i+1).equals("0")&&dest.substring(i,i+1).equals("0"))
                result = result + "0";
            else
                result = result + "1";
        }
        return result;
    }

    String xor(String src, String dest) {
        String result="";
        for(int i=0;i<src.length();i++){
            if(src.substring(i,i+1).equals(dest.substring(i,i+1)))
                result = result + "0";
            else
                result = result + "1";
        }
        return result;
    }

    String shl(String src, String dest) {
        int num = Integer.parseInt(new Transformer().binaryToInt(src));
        for(int i=0;i<num&&i<32;i++){
            dest = dest.substring(1) + "0";
        }
        return dest;
    }

    String shr(String src, String dest) {
        int num = Integer.parseInt(new Transformer().binaryToInt(src));
        for(int i=0;i<num&&i<dest.length();i++){
            dest = "0" + dest.substring(0,dest.length()-1);
        }
        return dest;
    }

    String sal(String src, String dest) {
        return shl(src,dest);
    }

    String sar(String src, String dest) {
        int num = Integer.parseInt(new Transformer().binaryToInt(src));
        for(int i=0;i<num&&i<dest.length();i++){
            dest = dest.substring(0,1) + dest.substring(0,31);
        }
        return dest;
    }

    String rol(String src, String dest) {
        int num = Integer.parseInt(new Transformer().binaryToInt(src));
        for (int i=0;i<num;i++){
            dest = dest.substring(1) + dest.substring(0,1);
        }
        return dest;
    }

    String ror(String src, String dest) {
        int num = Integer.parseInt(new Transformer().binaryToInt(src));
        for (int i=0;i<num;i++){
            dest = dest.substring(31) + dest.substring(0,31);
        }
        return dest;
    }

}
