import java.io.*;
import java.util.ArrayList;

public class CSVFile {


	public static void main(String[] args) {
		String filePath = CSVFile.class.getClassLoader().getResource("data.txt").getPath();
			printCSVFile(filePath);
	}
	
	public static void printCSVFile(String filePath) {
		//add code here
		try {
			ArrayList<String[]> csv= new ArrayList<>();
			File myFile=new File(filePath);
			BufferedReader input=new BufferedReader(new FileReader(myFile));
			String a=null;
			while((a=input.readLine())!=null){
				csv.add(a.split(","));

			}
			System.out.println("Last    Fisrt    Salary");
			for(String [] temp:csv){
				System.out.println(temp[0]+"    "+temp[1]+"    "+temp[2]);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	}

	


