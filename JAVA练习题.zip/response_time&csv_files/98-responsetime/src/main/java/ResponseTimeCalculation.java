//import sun.font.TrueTypeFont;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import static java.lang.StrictMath.sqrt;

public class ResponseTimeCalculation {

	public static void main(String[] args){
		double average=0;
		double deviation=0;
		String s;

		ArrayList<Integer> time= new ArrayList<>();
		int i=0;

		int maximum=Integer.MIN_VALUE;
		int minimum=Integer.MAX_VALUE;

		try {
			BufferedReader input=new BufferedReader(new InputStreamReader(System.in));
			while(true) {
				System.out.println("Enter a Number:");
				s=input.readLine();
				if(s.equals("done"))
					break;
				time.add(Integer.parseInt(s));
			}

		}catch (IOException e){
				e.printStackTrace();
			}

		for(int num:time){
			average+=num;
			minimum=Math.min(minimum,num);
			maximum=Math.max(maximum,num);
		}
		average=average/(time.size());
		for(int num:time){
			deviation+=(num-average)*(num-average);
		}
		deviation=sqrt(deviation/time.size());
		System.out.printf("Numbers:%d",time.get(0));
		for(i=1;i<time.size();i++){
			System.out.printf(",%d",time.get(i));
		}
		System.out.println("");
		System.out.printf("The average is %.2f.\n",average);
		System.out.printf("The minimum is %d.\n",minimum);
		System.out.printf("The maximum is %d.\n",maximum);
		System.out.printf("The standard deviation is %.2f.\n",deviation);
		}

	}
