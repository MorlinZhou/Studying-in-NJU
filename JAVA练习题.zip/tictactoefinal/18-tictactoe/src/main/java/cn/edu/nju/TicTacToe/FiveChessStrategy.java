package cn.edu.nju.TicTacToe;

public class FiveChessStrategy extends GameChessStrategy implements FiveChessMode {

    public FiveChessStrategy(){
        //1.initialize
        for (int i=0;i<X_recentFiveMoves.length;i++){
            X_recentFiveMoves[i]="-";
            O_recentFiveMoves[i]="-";
        }
    }

    @Override
    public void putChess(char[][] cells, Player currentPlayer, String chessPos) {
        super.putChess(cells, currentPlayer, chessPos);

        deleteMove(cells,chessPos,currentPlayer);
        recordMove(chessPos,currentPlayer);
    }
    @Override
    public void recordMove(String currentMove, Player currentPlayer){
        switch (currentPlayer){
            case O:
                if (O_recentFiveMoves[0].equals("-")){
                    O_recentFiveMoves[0]=currentMove;
                }else {
                    System.out.print("Error!");
                }
                break;
            case X:
                if (X_recentFiveMoves[0].equals("-")){
                    X_recentFiveMoves[0]=currentMove;
                }else {
                    System.out.print("Error!");
                }
                break;
        }
    }
    @Override
    public void deleteMove(char[][] cells,String currentMove, Player currentPlayer) {
        switch (currentPlayer){
            case O:
                if (!O_recentFiveMoves[4].equals("-")){
                    //如果五格满了删除
                    clearChess(cells,O_recentFiveMoves[4]);
                }
                //数据右移
                for(int i=O_recentFiveMoves.length-1;i>=1;i--){
                    O_recentFiveMoves[i]=O_recentFiveMoves[i-1];
                }
                O_recentFiveMoves[0]="-";
                break;

            case X:
                if (!X_recentFiveMoves[4].equals("-")){
                    clearChess(cells,X_recentFiveMoves[4]);
                }
                for(int i=X_recentFiveMoves.length-1;i>=1;i--){
                    X_recentFiveMoves[i]=X_recentFiveMoves[i-1];
                }
                X_recentFiveMoves[0]="-";
                break;
        }
    }

    public void clearChess(char[][] cells,String chessPos){
        try {
            int i = chessPos.charAt(1) - '1';
            int j = chessPos.charAt(0) - 'A';
            cells[i][j] = '_';
        }catch (Exception e){
            System.out.print("0 0");
        }
    }
}
