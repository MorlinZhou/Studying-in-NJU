package cn.edu.nju.TicTacToe;

public interface FiveChessMode {
    String[] X_recentFiveMoves = {"-","-","-","-","-"};
    String[] O_recentFiveMoves = {"-","-","-","-","-"};

    public void recordMove(String currentMove, Player currentPlayer);
    public void deleteMove(char[][] cells,String currentMove, Player currentPlayer);
}
