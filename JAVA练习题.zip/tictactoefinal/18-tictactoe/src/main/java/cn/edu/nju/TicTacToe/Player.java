package cn.edu.nju.TicTacToe;
/**
 * 不建议修改本枚举类型
 * @author Xin Feng & Qiu Liu
 */
public enum Player {
	X, O
}
