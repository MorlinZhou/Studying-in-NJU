package cn.edu.nju.TicTacToe;
public class Board {
	/**
	 * 成员变量的初始化代码请修改，请灵活选择初始化方式
	 * 必要时可添加成员变量
	 */
	protected char[][] cells;
	protected GameChessStrategy chessStrategy;
	protected GameWinStrategy_HVD winStrategy;
	protected Player player = Player.X;

	/**
	 * 请修改构造方法，并添加合适的构造方法
	 */
	public Board(int size,String gameMode){
		cells = new char[size][size];
		for(int i=0; i<size; i++){
			for(int j=0; j<size; j++){
				cells[i][j] = '_';
			}
		}
		char chessmode=gameMode.charAt(0);
		char winmode=gameMode.charAt(1);
		if(chessmode=='0'){
			chessStrategy=new GameChessStrategy();
		}
		else chessStrategy=new FiveChessStrategy();

		if(winmode=='0'){
			winStrategy=new GameWinStrategy_HVD();
		}
		else winStrategy=new GameWinStrategy_HV();
	}



	/**
	 * @param move 下棋的位置 范例是 A1
	 * @return 落棋之后的结果
	 */
	public Result nextMove(String move) {
		chessStrategy.putChess(cells, nextPlay(), move);
		return winStrategy.check(cells);
	}

	/**
	 * @return 下一个落棋的玩家
	 */
	protected Player nextPlay(){
		Player res = player;
		player = player == Player.X ? Player.O : Player.X;
		return res;
	}

	/**
	 * 棋盘的输出方法，根据需要进行修改
	 */
	public void print(){

		System.out.print("  ");
		for(int i=0;i<cells[0].length-1;i++){
			System.out.print(((char) ('A'+i))+" ");
		}
		System.out.println(((char)('A'+cells[0].length-1)));


		for(int i=0 ;i<cells[0].length; i++){
			System.out.print(i+1);
			for(int j=0; j<cells[0].length; j++){
				System.out.print(" "+cells[i][j]);
			}
			System.out.println();
		}
	}
}