import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CurrencyCalculation {

	public static void main(String[] args)  {
		float euros=0;
		float rate=0;
		float dollars;
		try {
			BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("How many euros are you exchanging?");
			euros = Float.parseFloat(input.readLine());
			System.out.println("What is the exchange rate?");
			rate = Float.parseFloat(input.readLine());
		}catch (IOException e){
			e.printStackTrace();
		}
		dollars=euros*rate/100;
		System.out.println(String.format("%.2f euros at an exchange rate of %.2f is %.2f U.S. dollars.",euros,rate,dollars));
	}

}
