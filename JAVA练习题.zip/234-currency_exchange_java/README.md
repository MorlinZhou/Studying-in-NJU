java
CurrencyExchange

##  题目要求
编写一个货币兑换程序，将欧元兑换成美元。提示输入手中的欧元数，以及欧元的当前汇率。打印可以兑换的美元数。

注意：使用英文标点符号，输出中的数字保留两位小数。

##  示例
输出：	How many euros are you exchanging?  
输入：	81  
输出：	What is the exchange rate?  
输入：	137.51  
输出：	81.00 euros at an exchange rate of 137.51 is 111.38 U.S. dollars.