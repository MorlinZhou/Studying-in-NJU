public class GameChessStrategy {
    /**
     * @param cells  棋盘对应的char二维数组
     * @param currentPlayer  当前落子的玩家
     * @param chessPos  下棋位置的字符串表示
     */
    private String[] positions=new String[10];
    private int index=0;
    public void putChess(char[][] cells, Player currentPlayer, String chessPos) {
            int i = chessPos.charAt(1) - '1';
            int j = chessPos.charAt(0) - 'A';
            cells[i][j] = (currentPlayer == Player.X ? 'X' : 'O');
            positions[index]=chessPos;
            index=index+1;
            if (index == 10) {
                index=0;
            }
        }
    }
