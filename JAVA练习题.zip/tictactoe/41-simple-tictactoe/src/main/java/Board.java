public class Board {

    protected char[][] cells;
    protected GameChessStrategy chessStrategy;
    protected GameWinWay winWay;
    protected Player player = Player.X;
    private final int boardSize = 3;




    //棋盘构造方法
    public Board() {
        cells = new char[3][3];
        for (int i = 0; i < boardSize; i++) {
            for (int j = 0; j < boardSize; j++) {
                cells[i][j] = '_';
            }
        }


        //落子方法
        chessStrategy = new GameChessStrategy();
        winWay = new GameWinWay();


    }
    //下一步落子并判断
    public Result nextMove(String move) {
        chessStrategy.putChess(cells, nextPlay(), move);
        return winWay.check(cells);
    }

    protected Player nextPlay(){
        Player res = player;
        player = (player == Player.X ? Player.O : Player.X);
        return res;
    }


    public void print() {
        System.out.println("  A B C");
        for (int i = 0; i < boardSize ; i++) {
            System.out.print(i+1);

            for (int j = 0; j < boardSize; j++) {
                System.out.print(" " + cells[i][j]);
            }
            System.out.println();
        }
    }
}
