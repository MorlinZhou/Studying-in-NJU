# MyMatrix #

1. 实现矩阵的加法、乘法、toString方法。
2. 理解如何overriding equals方法。
