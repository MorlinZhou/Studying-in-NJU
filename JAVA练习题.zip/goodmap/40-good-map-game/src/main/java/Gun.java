/**
 * Created by Shifang on 2017/10/21.
 * 武器类，请不要改动
 */
public class Gun {

    private final int damage = 1; //伤害值,请不要修改
    private final int range = 3;  //射程,请不要修改

    public int getDamage() {  //修改
        return damage;
    }

    public int getRange() {  //修改
        return range;
    }

}
