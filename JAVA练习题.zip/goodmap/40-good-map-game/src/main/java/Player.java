/**
 * Created by Shifang on 2017/10/24.
 * 玩家，请补全部分方法的代码，如有必要，你可以添加一些方法
 */
public class Player {

    private int x;
    private int y;
    private int healthPoint; //用来表示玩家的血量
    private String symbol;//用来表示此player的符号，如X，Y
    private boolean isHide; // 当前状态， true表示隐身
    private Gun gun = new Gun(); // 玩家的武器

    public Player(int x, int y, int healthPoint, String symbol) {
        this.x = x;
        this.y = y;
        this.healthPoint = healthPoint;
        this.symbol = symbol;
        this.isHide = false;
    }

    /**
     * 请在这里编写代码
     * 计算两者之间的距离
     *
     * @param player
     * @return 二者之间的距离
     */
    public double calDistance(Player player) {
        return Math.sqrt(Math.pow(this.x-player.getX(),2)+Math.pow(this.y-player.getY(),2));
    }

    /**
     * 请在这里编写代码
     * 根据输入的指令进行移动，指令有：'U', 'D', 'L', 'R'， 分别表示上，下，左，右；其中，上下改变x，左右改变y
     *
     * @param Move
     */
    public void move(String  Move,Player another) {
        char move=Move.charAt(0);
        if(move=='U')
            this.x--;
        else if(move=='D')
            this.x++;
        else if(move=='L')
            this.y--;
        else this.y++;
        if(Move.charAt(1)=='1')
        {
            if(calDistance(another)<=this.gun.getRange())
                another.damage(this.gun.getDamage());
        }
        if(Move.charAt(2)=='1')
            isHide=true;
        else
            isHide=false;


    }

    /**
     * 请在此方法中编写代码
     *
     * @return 当前player的符号，若isHide为true,则用小写字母表示， 否则用大写字母表示
     */
    public String getSymbol() {
        if(isHide)
            return symbol.toLowerCase();
        return  symbol.toUpperCase();
    }

    /**
     * @return x轴坐标
     */
    public int getX() {
        return x;
    }

    /**
     * @return y轴坐标
     */
    public int getY() {
        return y;
    }

    public  void damage(int damage)
    {
        this.healthPoint-=damage;
    }

    public  int get_HP(){
        return  healthPoint;
    }



}
