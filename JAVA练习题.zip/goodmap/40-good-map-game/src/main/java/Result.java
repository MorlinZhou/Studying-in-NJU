/**
 * Created by Shifang on 2017/10/21.
 * 游戏结果，请不要改动
 */
public enum Result {
    /**
     * X_WIN：代表 X 胜利
     * Y_WIN: 代表 Y 胜利
     * DRAW： 代表平局
     */
    X_WIN, Y_WIN,DRAW
}
