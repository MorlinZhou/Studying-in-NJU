/**
 * Created by lujxu on 2017/11/6.
 */
public enum Result {
    /**
     * ENCOUNTER：代表二者相遇
     * DRAW：代表二者始终未相遇，平局
     */
    ENCOUNTER,DRAW
}
