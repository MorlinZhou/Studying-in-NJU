import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CompareNumbers {

	public static void main(String[] args) {
		int a=0,b=0,c=0;
		BufferedReader input=new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter the first number:");
		try {
			a=Integer.parseInt(input.readLine());
			System.out.println("Enter the second number:");
			b=Integer.parseInt(input.readLine());
			System.out.println("Enter the third number:");
			c=Integer.parseInt(input.readLine());

		} catch (IOException e) {
			e.printStackTrace();
		}
		if (a==b||a==c||b==c) {
			System.out.println("There are same numbers.");
		}
		if(a>b&&a>c){
			System.out.println("The largest number is "+a+".");
		}
		if(b>a&&b>c){
			System.out.println("The largest number is "+b+".");
		}
		if(c>a&&c>b){
			System.out.println("The largest number is "+c+".");
		}

	}

}
