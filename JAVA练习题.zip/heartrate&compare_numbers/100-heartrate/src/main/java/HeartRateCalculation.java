import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class HeartRateCalculation {

	public static void main(String[] args) {
		double target=0;
		double rest=0;
		double age=0;
		String temp;
		try{
			BufferedReader input=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("RestingHR");
			temp=input.readLine();
			rest=Double.parseDouble(temp);
			System.out.println("Age:");
			temp=input.readLine();
			age=Double.parseDouble(temp);

		}catch (IOException e){
			e.printStackTrace();
		}
		System.out.println("Intensity|TargetHeartRate");
		System.out.println("---------|---------------");
		for(int i =55;i<=95;i+=5){
			target=(((220-age)-rest)*i/100)+rest;
			System.out.println(i+"%      |"+Math.round(target)+"bpm");
		}
	}

}
