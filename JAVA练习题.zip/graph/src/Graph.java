import java.util.ArrayList;

public class Graph {

    public static void main(String[] args){
        Graph graph=new Graph();
        int[][] test1 = {{0,0,0,1,0},
                         {0,0,0,0,0},
                         {0,0,0,0,0},
                         {1,0,0,0,0},
                         {0,0,0,1,1}};

        graph.setGraphSize(5);
        graph.setGraph(test1);

        for (int i=0;i<graph.getGraphSize();i++){
            graph.findLoop(i);
        }

        System.out.println("--------------");


    }
    private int graphSize;
    private int[][] graph;
    private ArrayList way=new ArrayList<>();
    public void setGraphSize(int size) {
        this.graphSize=size;
    }

    public int getGraphSize(){
        return graphSize;
    }

    public void setGraph(int[][] graph){
        this.graph=graph;
    }

    public boolean findState(int begin,int end){
        if (this.graph[begin][end]==1){
            return true;
        }
        else {
            return false;
        }
    }

    public boolean checkWay(int i){
        for (int k=0;k<way.size();k++){
            if (Integer.valueOf(i).equals(way.get(k))){
                return false;
            }
        }
        return true;
    }

    public void findWay(int begin,int end){
        if (begin==end){
            System.out.println(way);
            way.remove(way.size()-1);
            return;
        }
        for (int i=0;i<graphSize;i++){
            if (findState(begin, i) && checkWay(i)){
                way.add(i);
                findWay(i, end);//dfs递归
            }
        }
        way.remove(way.size()-1);
        return;
    }

    public void findLoop(int begin){
        for (int i=0;i<graphSize;i++){
            if (findState(begin, i)){
                way.add(i);
                findWay(i, begin);
            }
        }
    }

    }

