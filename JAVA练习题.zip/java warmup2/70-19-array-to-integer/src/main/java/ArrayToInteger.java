import java.lang.Object;
public class ArrayToInteger {

	public static int getInteger(int[] numbers) {
		int result = 0;
		if (numbers[0] >= 1 && numbers.length >= 10) {
			return Integer.MAX_VALUE;

		} else if (numbers[0] == 0) {
			for (int i = 1; i < numbers.length; i++) {
				result = result * 10 + numbers[i];
			}
		} else {
			for (int i = 0; i < numbers.length; i++) {
				result = result * 10 + numbers[i];
			}
		}
		return result;
	}
}