
public class CheckOddEven {

	public static boolean isOdd(int num){
	if(num%2==0)
		return false;
	else return true;
	}
}
