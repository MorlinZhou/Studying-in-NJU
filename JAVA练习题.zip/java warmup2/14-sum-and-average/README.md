##  题目要求   
#### 输出lowerbound到upperbound之间整数的和以及平均值。

##  示例
>输入：1 100

>输出：
The sum is 5050
The average is 50.5
