

public class MathStudy{
	/**
	 * 学习Math的abs方法，学会自己实现一个abs方法
	 * @param d
	 * @return 绝对值
	 */
	public static double abs(double d){
		if(d>=0.0){
			return d;
		}
		else return -d;
	}
	
	

	
	
}