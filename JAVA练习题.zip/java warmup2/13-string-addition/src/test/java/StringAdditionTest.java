
import static org.junit.Assert.*;

import org.junit.Test;

public class StringAdditionTest {

	@Test
	public void testAddPositive() {
		assertEquals("11", StringAddition.add("9","2"));
	}
	
	@Test
	public void testAddNegative() {
		assertEquals("-11", StringAddition.add("-9","-2"));
	}
	
	@Test
	public void testIntegerOverflow() {
		assertEquals("2147483648", StringAddition.add("2147483647","1"));
	}
	
	@Test
	public void testIntegerUnderflow() {
		assertEquals("-2147483649", StringAddition.add("-2147483648","-1"));
	}
	
	@Test
	public void testPositiveNegative() {
		assertEquals("0", StringAddition.add("-2147483647","2147483647"));
	}
}
