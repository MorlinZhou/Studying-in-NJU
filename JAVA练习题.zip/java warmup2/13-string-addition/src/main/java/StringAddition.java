import java.io.IOException;

public class StringAddition {

	public static String add(String s1, String s2) {
		long first=Integer.parseInt(s1);
		long second=Integer.parseInt(s2);
		String rst;
		rst=Long.toString(first+second);


		return rst;
    }
	   
}