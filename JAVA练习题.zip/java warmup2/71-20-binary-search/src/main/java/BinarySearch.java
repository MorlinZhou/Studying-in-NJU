
public class BinarySearch {

	public static int search(int[] data, int target) {
		int left = 0;
		int right = data.length - 1;
		while (left <= right) {
			int middle = (left + right) / 2;
			if (target < data[middle]) {
				right = middle - 1;
			} else if (target > data[middle]) {
				left = middle + 1;
			} else {
				return middle;
			}

		}
		return -1;
	}
}