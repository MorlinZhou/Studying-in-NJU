import java.util.Arrays;

public class SingleCharacterI {

	public static char singleNumber(char[] characters) {
		if(characters==null){
			return '\0';
		}
		int num=0;
		for(int i =0;i<characters.length;i++){
			num=num^characters[i];


		}
		return (char) num;
    }

}