
public class PrintNumberInWord {
	public String Number2String(int input){
		String result;
		result=String.valueOf(input);
		return result;
	}
}
