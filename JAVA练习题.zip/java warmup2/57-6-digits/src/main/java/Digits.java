
public class Digits {
	public String reverseInt(int input){
		int sum = 0;
		String numbers;
		numbers=String.valueOf(input);
		return new StringBuilder(numbers).reverse().toString();
	}
}
