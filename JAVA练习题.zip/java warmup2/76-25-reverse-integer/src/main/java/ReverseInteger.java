
public class ReverseInteger {
	 public static int reverseInteger(int n) {
	 	int count=1;
	 	if(n<0){
	 		count=-1;
	 		n=n*count;
		}
	 	String culcu=String.valueOf(n);
	 	culcu= new StringBuilder(culcu).reverse().toString();

	 	n=Integer.valueOf(culcu).intValue();
	 	return n*count;
	    
	 }
}
