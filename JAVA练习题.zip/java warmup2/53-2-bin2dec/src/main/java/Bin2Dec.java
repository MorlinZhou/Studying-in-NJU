import java.io.BufferedReader;
import java.util.ArrayList;

public class Bin2Dec {

	public String bin2dec(String input){
		int result = 0;
		String answer;
		String []binary=input.split("");
		for(int i=0;i<binary.length;i++){
			if(binary[i].equals("1")){
				result+=Math.pow(2,binary.length-1-i);
			}
		}
		answer=String.valueOf(result);
		return answer;
	}

}
