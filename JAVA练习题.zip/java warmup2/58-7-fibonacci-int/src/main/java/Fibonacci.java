
public class Fibonacci {
	public int FibonacciN(int input){
		int result=0;
		if(input==0){
			return 0;
		}
		else if(input==1){
			return 1;
		}
		else {
			result=FibonacciN(input-1)+FibonacciN(input-2);
		}
		return result;
	}
}
