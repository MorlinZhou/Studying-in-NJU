
public class AddDigits {

	 public static int addDigits(int num) {
	 	int result=0;
		 while(num/10>0){
	 		result+=num%10;
	 		num/=10;
		}
		 result+=num;
	 	if(result>=10){
	 		result=addDigits(result);
		}
	 	return result;
	 }
}
