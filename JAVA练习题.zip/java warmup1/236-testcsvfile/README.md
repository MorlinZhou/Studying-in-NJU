java
CSVFile

##  题目要求
编写一个程序，读入以下数据文件：  

Ling,Mai,55900  
Johnson,Jim,56500  
Zarnecki,Sabrina,51500  

处理该记录，并以格式化的表格形式显示结果，间隔均匀（4个空格）。  
注意：标点符号均为英文标点符号。  

##  示例输出
Last    Fisrt    Salary  
Ling    Mai    55900  
Johnson    Jim    56500  
Zarnecki    Sabrina    51500  
