
public class ResponseTimeCalculation {

	public static void main(String[] args){

	}
	
}
