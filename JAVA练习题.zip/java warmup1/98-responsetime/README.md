java
ResponseTime

##  题目要求
编写一个程序，提示输入某个网站的响应时间，以毫秒表示，不断让用户输入值，直到用户输入“done”。该程序应打印平均时间（mean），最小时间（min），最大时间（max）和标准差（standard deviation）。

注意：所有输入均为正整数，平均值和标准差保留两位小数，其他输出为整数。

##  示例
输出：	Enter a Number:  
输入：	100  
输出：	Enter a Number:  
输入：	200  
输出：	Enter a Number:  
输入：	1000  
输出：	Enter a Number:  
输入：	300  
输出：	Enter a Number:  
输入：	done  
输出：	Numbers:100,200,1000,300  
输出：	The average is 400.00.  
输出：	The minimum is 100.  
输出：	The maximum is 1000.  
输出：	The standard deviation is 353.55.   