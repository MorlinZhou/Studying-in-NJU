Java
Hello World

要求HelloWorld类的helloWorld方法返回"Hello World!"字符串。
