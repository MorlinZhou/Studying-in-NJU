package edu.nju;

/**
 * Created by Moekr on 2017/10/30.
 */
public class HelloWorld {
    public String helloWorld(){
        return null;
    }
}
