
public class CompareNumbers {

	public static void main(String[] args) {
	}

}
