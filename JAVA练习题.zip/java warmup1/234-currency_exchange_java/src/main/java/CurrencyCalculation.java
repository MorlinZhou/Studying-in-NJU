
public class CurrencyCalculation {

	public static void main(String[] args) {
	}

}
