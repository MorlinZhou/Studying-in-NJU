
public class HeartRateCalculation {

	public static void main(String[] args) {

	}

}
