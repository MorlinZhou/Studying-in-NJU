import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class GradesHistogram {
	/**
	 * 编写该方法对文件进行处理，并打印直方图，可添加新的方法
	 * @param fileName 处理的文件名
	 */
	public static void histogram(String fileName){
		int numbers;
		int range=0;
		int[] count=new int[10];
		int[] grades=new int[100];

		try {
			BufferedReader input = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
			numbers = Integer.parseInt(input.readLine());
			String[] store = (input.readLine()).split(" ");

			for (int i = 0; i < numbers; i++) {
				grades[i] = Integer.parseInt(store[i]);
			}

			for (int i = 0; i < numbers; i++) {
				if (grades[i] == 100) {
					count[9]++;//吧100算在90-100中
				}


				for (int j = 0; j <= 90; j += 10) {
					if (grades[i] >= j && grades[i] <= (j + 9)) {
						range = j / 10;//分类
						count[range]++;//计数
						break;
					}
				}
			}
		}catch(IOException e){
			e.printStackTrace();


		}
		System.out.print(" 0 -  9:");
		for (int i = 1;i<=count[0];i++){
			System.out.print("*");
		}
		System.out.println();//单独输出0-9

		for(int i = 1;i<9;i++){
			System.out.printf("%d - %d:",(i*10),(i*10+9));
			for (int j=1;j<=count[i];j++){
				System.out.print("*");
			}
			System.out.println();
		}//十位数是1-8的可以放一起

		System.out.print("90 -100:");
		for(int i = 1;i<=count[9];i++){
			System.out.print("*");
		}
	}//90-100是特殊情况，单独输出
}
